export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const batch_id = formData.get('batch_id') as string;
    const document_type_id = formData.get('document_type_id') as string;
    
    if (!file || !batch_id || !document_type_id) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    // Generate document number
    const { data: docType } = await supabase
      .from('qa_document_types')
      .select('code')
      .eq('id', document_type_id)
      .single();
    
    const docNumber = await generateDocumentNumber(docType.code);
    
    // In a real app, you would upload the file to storage
    // For now, we'll just save the record
    const { data, error } = await supabase
      .from('qa_documents')
      .insert({
        batch_id,
        document_type_id,
        document_number: docNumber,
        file_name: file.name,
        file_url: `placeholder-url-${Date.now()}`, // In production, upload to storage
        status: 'pending',
        uploaded_by: formData.get('uploaded_by') as string || 'System',
        uploaded_at: new Date().toISOString()
      })
      .select()
      .single();
    
    if (error) {
      console.error('Error uploading document:', error);
      return NextResponse.json(
        { error: 'Failed to upload document' },
        { status: 500 }
      );
    }
    
    return NextResponse.json(data);
    
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Failed to upload document' },
      { status: 500 }
    );
  }
}

async function generateDocumentNumber(docType: string): Promise<string> {
  const year = new Date().getFullYear();
  const { count } = await supabase
    .from('qa_documents')
    .select('*', { count: 'exact', head: true })
    .like('document_number', `${docType}-${year}-%`);
  
  const sequence = (count || 0) + 1;
  return `${docType}-${year}-${String(sequence).padStart(5, '0')}`;
}