export default function ProductsPage() {
  return <div className="p-6">Products – coming soon</div>;
}
