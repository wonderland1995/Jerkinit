export default function ReportsPage() {
  return <div className="p-6">Reports – coming soon</div>;
}
