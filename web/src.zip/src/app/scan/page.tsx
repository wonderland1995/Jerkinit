export default function ScanPage() {
  return <div className="p-6">Scan – coming soon</div>;
}
